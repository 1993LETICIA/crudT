/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

public class FormPrincipal extends javax.swing.JFrame {

    public FormPrincipal() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        barraMenu = new javax.swing.JMenuBar();
        menuCadastro = new javax.swing.JMenu();
        menuDestino = new javax.swing.JMenuItem();
        menuFuncionario = new javax.swing.JMenuItem();
        menuLojaDeDestino = new javax.swing.JMenuItem();
        menuLivraria = new javax.swing.JMenuItem();
        menuAjuda = new javax.swing.JMenu();
        menuSobre = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sistema de Destino");

        menuCadastro.setText("Cadastro");

        menuDestino.setText("Destino");
        menuDestino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuDestinoActionPerformed(evt);
            }
        });
        menuCadastro.add(menuDestino);

        menuFuncionario.setText("Funcionario");
        menuFuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuFuncionarioActionPerformed(evt);
            }
        });
        menuCadastro.add(menuFuncionario);

        menuLojaDeDestino.setText("Loja De Destino");
        menuLojaDeDestino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuLojaDeDestinoActionPerformed(evt);
            }
        });
        menuCadastro.add(menuLojaDeDestino);

        menuLivraria.setText("Livraria");
        menuLivraria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuLivrariaActionPerformed(evt);
            }
        });
        menuCadastro.add(menuLivraria);

        barraMenu.add(menuCadastro);

        menuAjuda.setText("Ajuda");

        menuSobre.setText("Sobre");
        menuSobre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuSobreActionPerformed(evt);
            }
        });
        menuAjuda.add(menuSobre);

        barraMenu.add(menuAjuda);

        setJMenuBar(barraMenu);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 279, Short.MAX_VALUE)
        );

        getAccessibleContext().setAccessibleName("Sistema Transportadora");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void menuDestinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuDestinoActionPerformed
        // TODO add your handling code here:
        FormDestino form = new FormDestino(this, true);
        form.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);//não vai fechar no x
        form.setLocationRelativeTo(null);//centraliza na tela
        form.setResizable(false);//tira o botão maximizar
        form.setVisible(true);// torna o fórmulário vísivel 
    }//GEN-LAST:event_menuDestinoActionPerformed

    private void menuSobreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuSobreActionPerformed
        JOptionPane.showMessageDialog(null, "Sistema de Cadastro\n versao 1.0\n Todos os Direitos Reservados");
    }//GEN-LAST:event_menuSobreActionPerformed

    private void menuFuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuFuncionarioActionPerformed
        // TODO add your handling code here:
        // TODO add your handling code here:
        FormFuncionario form = new FormFuncionario(this, true);
        form.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);//não vai fechar no x
        form.setLocationRelativeTo(null);//centraliza na tela
        form.setResizable(false);//tira o botão maximizar
        form.setVisible(true);// torna o fórmulário vísivel 
    }//GEN-LAST:event_menuFuncionarioActionPerformed

    private void menuLojaDeDestinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuLojaDeDestinoActionPerformed
        // TODO add your handling code here:
        FormLoja_De_Destino form = new FormLoja_De_Destino(this, true);
        form.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);//não vai fechar no x
        form.setLocationRelativeTo(null);//centraliza na tela
        form.setResizable(false);//tira o botão maximizar
        form.setVisible(true);// torna o fórmulário vísivel 
    }//GEN-LAST:event_menuLojaDeDestinoActionPerformed

    private void menuLivrariaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuLivrariaActionPerformed
        // TODO add your handling code here:
        FormLivraria form = new FormLivraria(this, true);
        form.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);//não vai fechar no x
        form.setLocationRelativeTo(null);//centraliza na tela
        form.setResizable(false);//tira o botão maximizar
        form.setVisible(true);// torna o fórmulário vísivel 
    }//GEN-LAST:event_menuLivrariaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                // new FormPrincipal().setVisible(true);
                FormPrincipal form = new FormPrincipal();
                form.setLocationRelativeTo(null);
                form.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuBar barraMenu;
    private javax.swing.JMenu menuAjuda;
    private javax.swing.JMenu menuCadastro;
    private javax.swing.JMenuItem menuDestino;
    private javax.swing.JMenuItem menuFuncionario;
    private javax.swing.JMenuItem menuLivraria;
    private javax.swing.JMenuItem menuLojaDeDestino;
    private javax.swing.JMenuItem menuSobre;
    // End of variables declaration//GEN-END:variables
}
