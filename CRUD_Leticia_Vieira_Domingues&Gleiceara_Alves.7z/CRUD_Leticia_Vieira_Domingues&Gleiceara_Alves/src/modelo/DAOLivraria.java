/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class DAOLivraria {
    public Livraria localizar(Integer id){
         String sql = "select * from livraria where codLivraria=?";
         Livraria obj = new Livraria();
         try{
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
                obj.setCodLivraria(rs.getInt("codLivraria"));
                obj.setNome(rs.getString("nome"));
                obj.setEndereco(rs.getString("endereco"));
                obj.setCidade(rs.getString("cidade"));
                obj.setUf(rs.getString("uf"));
                return obj;
            }
         }catch(SQLException e){
             JOptionPane.showMessageDialog(null, "Erro de SQL Localizar DaoLivraria"+e.getMessage());
         }
         return null;
     } 
    
    /*********************************/

    public List <Livraria> getLista(){
       String sql = "select * from livraria;";
       List<Livraria> lista = new ArrayList <>();
       try{
           PreparedStatement pst = Conexao.getPreparedStatement(sql);
           ResultSet rs = pst.executeQuery();
           while(rs.next()){
               Livraria obj = new Livraria();
               obj.setCodLivraria(rs.getInt("codLivraria"));
               obj.setNome(rs.getString("nome"));
               obj.setEndereco(rs.getString("endereco"));
               obj.setCidade(rs.getString("cidade"));
               obj.setUf(rs.getString("uf"));
               lista.add(obj);
           }
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null, "Erro de SQL no getLista()"+e.getMessage());
       }
          return lista; 
    }
    
    public boolean salvar(Livraria obj){
        if(obj.getCodLivraria()==null){
            return incluir(obj);
        }else{
            return alterar(obj);
        }
       
    }
    
    public boolean incluir(Livraria obj){
        String sql = "INSERT INTO `livraria` (`nome`, `endereco`, `cidade`, `uf`) VALUES (?,?,?,?);";
        try{
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setString(1, obj.getNome());
            pst.setString(2, obj.getEndereco());  
            pst.setString(3, obj.getCidade());
            pst.setString(4, obj.getUf());
            
            if(pst.executeUpdate()>0){
                JOptionPane.showMessageDialog(null, "Livraria cadastrado");
                return true; 
            }else{
                JOptionPane.showMessageDialog(null, "Livraria não cadastrado");
                return false;
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,"Erro de SQL no incluir do DAOLivraria"+e.getMessage());
        }
        return false;
    }
    public boolean alterar(Livraria obj){
       String sql ="UPDATE `livraria SET `nome`=?, `endereco`=?, `cidade`=?, `uf`=? WHERE  `codLivraria`=?;";
       try{
           PreparedStatement pst = Conexao.getPreparedStatement(sql);
           pst.setString(1,obj.getNome());
           pst.setString(2,obj.getEndereco());
           pst.setString(3,obj.getCidade());
           pst.setString(4,obj.getUf());
           pst.setInt(5, obj.getCodLivraria());
           if(pst.executeUpdate()>0){
               JOptionPane.showMessageDialog(null,"Livraria alterada");
               return true;
           }else{
               JOptionPane.showMessageDialog(null,"Livraria não alterada");
               return false;
           }
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null, "Erro de SQL no alterar do DAOLivraria"+e.getMessage());
       }
       return false;
   }
    
  
        public boolean remover(Livraria obj){
        String sql = "DELETE FROM `livraria` WHERE  `codLivraria`=?";
        try{
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, obj.getCodLivraria());
            if(pst.executeUpdate()>0){
                JOptionPane.showMessageDialog(null, "Livraria excluido");
                return true;
            }else{
                JOptionPane.showMessageDialog(null, "Livraria não excluido");
                return false;
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Erro do SQL no excluir do DAOLivraria"+e.getMessage());
        }
        return false;
    }
}
