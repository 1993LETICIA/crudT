package modelo;

import java.util.ArrayList;
import java.util.List;


public class Dados {
    
     public static List<Destino> listaDestino = new ArrayList<>();
     public static List<Funcionario> listaFuncionario = new ArrayList<>();
     public static List<Loja_De_Destino> listaLoja_De_Destino = new ArrayList<>();
     public static List<Livraria> listaLivraria = new ArrayList<>();
}
